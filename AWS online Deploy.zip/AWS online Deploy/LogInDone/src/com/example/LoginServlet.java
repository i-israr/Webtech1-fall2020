package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Connection con;
	private Statement stm;
	private String query;
	private ResultSet rs;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String userName="admin";
	   // String password= "123456";
		String clientUserName = request.getParameter("userNameIndex");
		String clientUserpassword = request.getParameter("passWordIndex");
		
		query = "select * from login where UserName='"+clientUserName+"' and password = '"+clientUserpassword+"'"; 
		System.out.println(query);
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");//loading drivers
		    System.out.println("Drivers loaded");
			con = DriverManager.getConnection("jdbc:mysql://mydatabase.curriydb9kwh.us-east-1.rds.amazonaws.com:3306/myDatabase","admin","123786Israr");
			stm = con.createStatement();
			rs = stm.executeQuery(query);
		} 
		catch (ClassNotFoundException e) {
			System.out.println("Drivers Not loaded");
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		RequestDispatcher dispatch;
		try {
			if(rs.next()) {
				//create session for identifying successive user requests
				HttpSession session=request.getSession();
				session.setAttribute("userName", clientUserName);
				
				dispatch = request.getRequestDispatcher("success.jsp");
				dispatch.forward(request, response);
			}
			else {
				// not successful block
				// forward the request/response to failure.jsp
				dispatch = request.getRequestDispatcher("failure.jsp");
				dispatch.forward(request, response);
			}
		} catch (SQLException | ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
