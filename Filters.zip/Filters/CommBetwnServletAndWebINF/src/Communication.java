

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Communication
 */
@WebServlet("/Communication")
public class Communication extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
		String clientUserName = request.getParameter("userNameIndex");
		String clientUserpassword = request.getParameter("passWordIndex");
//		System.out.println(clientUserName);
//		System.out.println(clientUserpassword);
		String name="israr";
		String pass="123";
		RequestDispatcher dispatch;
		//clientUserName==name && clientUserpassword==pass
		if(clientUserName.equals(name) && clientUserpassword.equals(pass)) {
//			request.setAttribute("username", clientUserName);
			//1. a brand new session will be created request.getSession()
			//2. or refernece already created session obj is returned "if no obj has been created" request.getSession(true)
			//3. refernece already created session obj and no new obj creation ever happen request.getSession(false) 
			HttpSession session = request.getSession();// get session does not mean that some obj is already created and ref is returned
			session.setAttribute("userName", clientUserName);			
			dispatch = request.getRequestDispatcher("Success.jsp");
			dispatch.forward(request, response);
		}else {
			dispatch = request.getRequestDispatcher("Fail.jsp");
			dispatch.forward(request, response);
		}	
	}

}
