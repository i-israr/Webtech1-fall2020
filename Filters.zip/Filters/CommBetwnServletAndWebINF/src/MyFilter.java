

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class MyFilter
 */
//@WebFilter("/MyFilter")
@WebFilter("/*")//this means that I am mapping this filter for all the requests
public class MyFilter implements Filter {

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}
	

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest aRequest = (HttpServletRequest) request;
		HttpSession session = aRequest.getSession(false);//I only monitoring the request which is about to hit my server.I dont want to create a session here 
		System.out.println("Filter Invoked for request reaching the server");
		// TODO Auto-generated method stub
		// place your code here
		if(session !=null)
		System.out.println("Is there any attribute saved in session cache  "+session.getAttribute("userName"));
		// pass the request along the filter chain
		chain.doFilter(request, response);	
		//This portion is invoke when the request is leaving the server.
		System.out.println("Filter Invoked for response leaving the server");
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}



}
